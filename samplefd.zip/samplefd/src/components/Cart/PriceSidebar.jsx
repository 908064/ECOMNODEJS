const PriceSidebar = ({ cartItems }) => {
    return (
        <div className="flex flex-col w-full sm:w-4/12 sm:px-4 sticky top-16 sm:top-20">

            {/* <!-- nav tiles --> */}
            <div className="flex flex-col bg-white rounded-sm shadow p-4 sm:p-6">
                <h1 className="px-6 py-3 border-b font-medium text-gray-500">PRICE DETAILS</h1>

                <div className="flex flex-col gap-4 p-4 pb-3 sm:p-6 sm:pb-3">
                    <p className="flex justify-between text-sm sm:text-base">Price ({cartItems.length} item{cartItems.length > 1 ? 's' : ''}) <span>₹{cartItems.reduce((sum, item) => sum + (item.cuttedPrice * item.quantity), 0).toLocaleString()}</span></p>
                    <p className="flex justify-between text-sm sm:text-base">Discount <span className="text-primary-green">- ₹{cartItems.reduce((sum, item) => sum + ((item.cuttedPrice * item.quantity) - (item.price * item.quantity)), 0).toLocaleString()}</span></p>
                    <p className="flex justify-between text-sm sm:text-base">Delivery Charges <span className="text-primary-green">FREE</span></p>

                    <div className="border-t border-dashed"></div>
                    <p className="flex justify-between text-lg font-medium">Total Amount <span>₹{cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0).toLocaleString()}</span></p>
                    <div className="border-t border-dashed"></div>

                    <p className="font-medium text-primary-green">You will save ₹{cartItems.reduce((sum, item) => sum + ((item.cuttedPrice * item.quantity) - (item.price * item.quantity)), 0).toLocaleString()} on this order</p>
                </div>
            </div>
            {/* <!-- nav tiles --> */}

        </div>
    );
};

export default PriceSidebar;

