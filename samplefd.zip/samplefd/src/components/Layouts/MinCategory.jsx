import React from 'react';
import { Link } from 'react-router-dom';
import '../../../src/components/Layouts/Categories.css';

// Array of category objects with name and icon
const catNav = [
    { name: "Food"},
    { name: "Fashion"},
    { name: "Electronics" },
    { name: "Home Appliances"},
    { name: "Electrical"},
    { name: "Mobile Parts"},
    { name: "Groceries"},
    { name: "Opticals"},
    { name: "Toys"},
    { name: "Vegetables"},
    { name: "Tools"},
    { name: "Mobile Accessories"},
    { name: "Gadgets"}
];

// Categories component
const Categories = () => {
    return (
        <section className="bg-white mt-10 mb-4 min-w-full px-12 py-1 shadow overflow-hidden">
            {/* Desktop view */}
            <div className="hidden sm:flex items-center justify-between mt-4 overflow-x-auto scrollbar-hide">
                {catNav.map((item, i) => (
                    <Link to={`/products?category=${item.name}`} className="flex flex-col gap-1 items-center p-2 group" key={i}>
                        
                        <span className="text-sm text-gray-800 font-medium group-hover:text-primary-blue">{item.name}</span>
                    </Link>
                ))}
            </div>

            
        </section>
    );
};

export default Categories;

