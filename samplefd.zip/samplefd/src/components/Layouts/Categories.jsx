import React from 'react';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import cfood from '../../assets/images/Categories/cfood.png';
import fashion from '../../assets/images/Categories/cfashion.png';
import celectronics from '../../assets/images/Categories/celectronics.png';
import chome from '../../assets/images/Categories/chome.png';
import celectrical from '../../assets/images/Categories/celectrical.png';
import cmobilepart from '../../assets/images/Categories/cmobilepart.png';
import cgrosery from '../../assets/images/Categories/cgrosery.png';
import copticals from '../../assets/images/Categories/copticals.png';
import ctoys from '../../assets/images/Categories/ctoys.png';
import cveg from '../../assets/images/Categories/cveg.png';
import ctools from '../../assets/images/Categories/ctools.png';
import cmobileaccessory from '../../assets/images/Categories/cmobileaccessory.png';
import cgatgets from '../../assets/images/Categories/cgatgets.png';
import { Link } from 'react-router-dom';
import '../../../src/components/Layouts/Categories.css';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/scrollbar';

// Array of category objects with name and icon
const catNav = [
    { name: "Electronics", icon: celectronics },
    { name: "Electrical", icon: celectrical },
    { name: "Tools", icon: ctools }, 
    { name: "Mobile Accessories", icon: cmobileaccessory },
    { name: "Mobile Parts", icon: cmobilepart },
    { name: "Gadgets", icon: cgatgets },
    { name: "Home Appliances", icon: chome },
    { name: "Fashion", icon: fashion },
    { name: "Food", icon: cfood },
    { name: "Vegetables", icon: cveg },
    { name: "Groceries", icon: cgrosery },
    { name: "Opticals", icon: copticals },
    { name: "Toys", icon: ctoys },
    ];

// Categories component
const Categories = () => {
    return (
        <section className="bg-white mt-10 mb-4 min-w-full px-5 py-1 shadow overflow-hidden">
            {/* Desktop view */}
            <div className="hidden sm:flex items-center justify-between mt-4 overflow-x-auto scrollbar-hide">
                {catNav.map((item, i) => (
                    <Link to={`/products?category=${item.name}`} className="flex flex-col gap-1 items-center p-2 group" key={i}>
                        <div className="h-16 w-16">
                            <img 
                                draggable="false" 
                                className="h-full w-full object-contain" 
                                src={item.icon} 
                                alt={item.name} 
                                style={{ border: '3px solid #282829', borderRadius: '40px' }} 
                            />
                        </div>
                        <span className="text-sm text-gray-800 font-medium group-hover:text-primary-blue">{item.name}</span>
                    </Link>
                ))}
            </div>
{/* mobile view */}
          
            <div className="sm:hidden mt-4">
            <Swiper
                slidesPerView={4}
                spaceBetween={10}
                centeredSlides={true}
                grabCursor={true}
            >
                {catNav.map((item, i) => (
                    <SwiperSlide key={i} style={{ width: '60.3px', margin: '5px' }}>
                        <Link to={`/products?category=${item.name}`} className="flex flex-col gap-1 items-center p-2 group">
                            <div className="h-10 w-10">
                                <img
                                    draggable="false"
                                    className="h-full w-full object-contain"
                                    src={item.icon}
                                    alt={item.name}
                                    style={{ border: '3px solid #282829', borderRadius: '40px' }}
                                />
                            </div>
                            <span className="text-sm p-2 text-gray-800 font-medium group-hover:text-primary-blue">{item.name}</span>
                        </Link>
                    </SwiperSlide>
                ))}
            </Swiper>
        </div>
        </section>
    );
};

export default Categories;